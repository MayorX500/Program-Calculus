# cp2021tStack

- PDF e .lhs na pasta app
- .hs na pasta src
